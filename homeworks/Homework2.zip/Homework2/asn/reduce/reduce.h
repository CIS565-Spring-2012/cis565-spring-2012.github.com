#ifndef _REDUCE_H_
#define _REDUCE_H_


#endif