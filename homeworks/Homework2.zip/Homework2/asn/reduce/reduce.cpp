#include "reduce.h"
#include "cutil_math.h"

// utilities and system includes
#include <cuda.h>
#include <cuda_runtime_api.h>
#include <vector_types.h>
#include <cstdio>

extern "C" 
float4 reduce(float4* dev_src, const unsigned int len);

/////////////////////////////////////////////////////////
///////////// CPU REFERENCE IMPLEMENTATION
/////////////////////////////////////////////////////////
float4 reduce_gold(float4* dev_src, const unsigned int len) {
  float4 * hst_src = new float4[len];
  cudaMemcpy(hst_src, dev_src, len * sizeof(float4), cudaMemcpyDeviceToHost); 
  float4 accum = make_float4(0.0f,0.0f,0.0f,0.0f);
  for (unsigned int i = 0; i < len; ++i) {
    accum.x += hst_src[i].x;
    accum.y += hst_src[i].y;
    accum.z += hst_src[i].z;
    accum.w += hst_src[i].w;
  }
  delete [] hst_src;
  return accum;
}

/////////////////////////////////////////////////////////
//////////// TEST HARNESS
/////////////////////////////////////////////////////////
int uploadToDevice(float4 * hst, const unsigned int len, 
    float4 ** dev_ptr_ptr, unsigned int * len_ptr) {
  float4 * dev = NULL;
  cudaMalloc((void**)&dev, sizeof(float4)*len);
  cudaMemcpy(dev, hst, len * sizeof(float4), cudaMemcpyHostToDevice);
  *len_ptr = len;
  *dev_ptr_ptr = dev;
  return 0;
}

int generate(int num, float4 (*generator)(int index),
    float4 ** dev_ptr_ptr, unsigned int  * len_ptr) {
  float4 * hst = new float4[num];
  for (int i = 0; i < num; ++i) {
    hst[i] = generator(i);
  }
  uploadToDevice(hst,num, dev_ptr_ptr, len_ptr);
  delete [] hst;
  return 0;
}

float4 gen1(int i) {
  return make_float4(1.0f*i, 2.0f*i, 4.0f*i, 8.0f*i);
}

float4 gen2(int i) {
  return make_float4(i / 100.0f, i / 1000.0f, i / 10.0f, 0);
}

float4 gen3(int i) {
  return make_float4(cos(i/1000.0f), sin(i/1000.0f), 1.0f, 0.0f);
}

float4 gen4(int i) {
  return make_float4(0.0f, 1.0f, sin(i/100.0f), cos(i/100.0f));
}

int setup1(float4 ** dev_ptr_ptr, unsigned int  * len_ptr) {
  const unsigned int NUM_PTS = 4096;
  return generate(NUM_PTS,gen1,dev_ptr_ptr, len_ptr); 
}

int setup2(float4 ** dev_ptr_ptr, unsigned int  * len_ptr) {
  const unsigned int NUM_PTS = 300;
  return generate(NUM_PTS,gen2,dev_ptr_ptr, len_ptr); 
}

int setup3(float4 ** dev_ptr_ptr, unsigned int  * len_ptr) {
  const unsigned int NUM_PTS = 12000;
  return generate(NUM_PTS,gen3,dev_ptr_ptr, len_ptr); 
}

int setup4(float4 ** dev_ptr_ptr, unsigned int  * len_ptr) {
  const unsigned int NUM_PTS = 8193;
  return generate(NUM_PTS,gen4,dev_ptr_ptr, len_ptr); 
}

bool test(int (*setup)(float4 ** dev_ptr_ptr, unsigned int  * len_ptr)) {
  float4 * dev;
  unsigned int len;
  setup(&dev, &len);
  float4 val = reduce_gold(dev,len);
  cudaFree(dev);
  setup(&dev, &len);
  float4 yours = reduce(dev,len);
  cudaFree(dev);
  float EPSILON = 0.1f;
  printf("Gold: %15.5f Yours: %15.5f \n", val.x, yours.x);
  printf("Gold: %15.5f Yours: %15.5f \n", val.y, yours.y);
  printf("Gold: %15.5f Yours: %15.5f \n", val.z, yours.z);
  printf("Gold: %15.5f Yours: %15.5f \n", val.w, yours.w);
  return (abs(val.x - yours.x) < EPSILON &&
      abs(val.y - yours.y) < EPSILON &&
      abs(val.z - yours.z) < EPSILON &&
      abs(val.w - yours.w) < EPSILON );
}

void report(char * tag, bool res) {
	printf("Test %s: %s\n", tag, res ? "PASSED" : "FAILED");
}

int testReduce() {
  report("1", test(setup1));
  report("2", test(setup2));
  report("3", test(setup3));
  report("4", test(setup4));
  return 0;
}

int
main( int argc, char** argv) {
  testReduce();
  getc(stdin);
  return 0;
}
